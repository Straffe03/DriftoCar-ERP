package Projecte2.DriftoCar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriftoCarApplicationTests {

	@Test
	void contextLoads() {
	}

}
